﻿namespace PizzaMore.Utilities
{
    public static class Constants
    {
        public static readonly string RequestMethod = "REQUEST_METHOD";
    }
}
