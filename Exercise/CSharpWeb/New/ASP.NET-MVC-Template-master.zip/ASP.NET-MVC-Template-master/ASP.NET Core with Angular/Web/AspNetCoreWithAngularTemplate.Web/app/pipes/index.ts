﻿export const APP_PIPES = [];
