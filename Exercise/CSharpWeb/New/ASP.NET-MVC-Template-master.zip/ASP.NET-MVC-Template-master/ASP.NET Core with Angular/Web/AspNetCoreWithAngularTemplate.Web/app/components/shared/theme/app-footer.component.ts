﻿import { Component } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'app-footer',
    templateUrl: 'app-footer.component.html'
})

export class AppFooterComponent { }
