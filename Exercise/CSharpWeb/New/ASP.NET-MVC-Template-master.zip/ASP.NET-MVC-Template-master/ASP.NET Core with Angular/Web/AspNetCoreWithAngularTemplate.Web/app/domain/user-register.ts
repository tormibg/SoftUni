﻿export class UserRegister {
    public email: string;

    public password: string;

    public passwordConfirmation: string;
}