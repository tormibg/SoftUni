﻿declare var $: any;
declare var System: any;
