﻿/// <reference path="../../node_modules/@types/core-js/index.d.ts" />

import { Component } from '@angular/core';

@Component({
    moduleId: module.id,
    selector: 'app-root',
    templateUrl: 'app.component.html'
})

export class AppComponent { }
