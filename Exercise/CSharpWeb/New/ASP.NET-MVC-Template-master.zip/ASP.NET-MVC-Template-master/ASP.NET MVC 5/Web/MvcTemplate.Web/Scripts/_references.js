﻿/// <reference path="jquery-3.3.1.js" />
/// <autosync enabled="true" />
/// <reference path="bootstrap.js" />
/// <reference path="jquery.validate.min.js" />
/// <reference path="jquery.validate.unobtrusive.js" />
