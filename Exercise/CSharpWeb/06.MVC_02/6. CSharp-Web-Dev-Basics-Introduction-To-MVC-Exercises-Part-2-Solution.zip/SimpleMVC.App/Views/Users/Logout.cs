﻿using SimpleMVC.Interfaces;

namespace SimpleMVC.App.Views.Users
{
    public class Logout  :IRenderable
    {
        public string Render()
        {
            string htmlContent = "";

            return htmlContent;
        }
    }
}
