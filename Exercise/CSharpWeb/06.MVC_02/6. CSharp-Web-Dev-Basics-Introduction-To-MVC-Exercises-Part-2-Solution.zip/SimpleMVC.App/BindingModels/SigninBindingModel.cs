﻿namespace SimpleMVC.App.BindingModels
{
    public class SigninBindingModel
    {
        public string SignInEmail { get; set; }

        public string SignInPassword { get; set; }
    }
}
