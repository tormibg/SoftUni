﻿namespace SimpleMVC.App.BindingModels
{
    public class SignupBindingModel
    {
        public string SignUpEmail { get; set; }

        public string SignUpPassword { get; set; }

    }
}
