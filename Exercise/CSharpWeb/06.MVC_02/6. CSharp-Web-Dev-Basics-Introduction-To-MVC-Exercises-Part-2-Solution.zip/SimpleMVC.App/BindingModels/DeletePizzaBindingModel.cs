﻿namespace SimpleMVC.App.BindingModels
{
    public class DeletePizzaBindingModel
    {
        public int PizzaId { get; set; }
    }
}
