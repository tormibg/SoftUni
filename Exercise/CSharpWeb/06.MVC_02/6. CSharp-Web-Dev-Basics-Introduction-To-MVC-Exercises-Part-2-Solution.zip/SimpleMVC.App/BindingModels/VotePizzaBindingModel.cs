﻿namespace SimpleMVC.App.BindingModels
{
    public class VotePizzaBindingModel
    {
        public int PizzaId { get; set; }

        public string PizzaVote { get; set; }
    }
}
