﻿namespace Shouter.BindingModels
{
    public class FollowerBindingModel
    {
        public int Id { get; set; }
    }
}
