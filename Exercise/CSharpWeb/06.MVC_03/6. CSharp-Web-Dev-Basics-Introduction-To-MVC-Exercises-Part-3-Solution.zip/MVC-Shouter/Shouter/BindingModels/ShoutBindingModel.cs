﻿namespace Shouter.BindingModels
{
    public class ShoutBindingModel
    {
        public string Content { get; set; }

        public int Lifetime { get; set; }
    }
}
