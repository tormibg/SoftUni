namespace Shouter.Migrations
{
    using System.Data.Entity.Migrations;
    
    public partial class addedShoutsNavPropToUser : DbMigration
    {
        public override void Up()
        {
        }
        
        public override void Down()
        {
        }
    }
}
