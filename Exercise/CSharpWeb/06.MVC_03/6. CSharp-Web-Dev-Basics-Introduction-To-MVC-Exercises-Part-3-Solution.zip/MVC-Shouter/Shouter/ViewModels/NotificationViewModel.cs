﻿namespace Shouter.ViewModels
{
    public class NotificationViewModel
    {
        public int UserId { get; set; }

        public string Username { get; set; }
    }
}
