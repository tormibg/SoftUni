﻿namespace Shouter.ViewModels
{
    public class FollowerViewModel  
    {
        public string Id { get; set; }

        public string Username { get; set; }

        public string FollowStatus { get; set; }

        public string FollowOption { get; set; }
    }
}
