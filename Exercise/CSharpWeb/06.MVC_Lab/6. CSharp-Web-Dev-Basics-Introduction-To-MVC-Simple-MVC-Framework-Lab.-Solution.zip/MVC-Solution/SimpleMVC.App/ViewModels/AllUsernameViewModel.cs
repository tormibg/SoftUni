﻿using System;
using System.Collections.Generic;

namespace SimpleMVC.App.ViewModels
{
    public class AllUsersViewModel
    {
        public int Id { get; set; }
        public string Username { get; set; }
    }
}
