﻿namespace SimpleMVC.App.BindingModels
{
    public class AddNoteBindingModel
    {
        public int UserId { get; set; }

        public string Title { get; set; }

        public string Content { get; set; }
    }
}
