var QuestionInputModel = (function () {
    function QuestionInputModel(id, title) {
        this._id = id;
        this.title = title;
    }

    return QuestionInputModel;
}());