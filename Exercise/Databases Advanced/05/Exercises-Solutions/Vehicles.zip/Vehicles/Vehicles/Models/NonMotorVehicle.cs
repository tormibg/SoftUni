﻿namespace Vehicles.Models
{
    using System.ComponentModel.DataAnnotations.Schema;

    [Table("NonMotorVehicles")]
    public class NonMotorVehicle : Vehicle
    {
    }
}
