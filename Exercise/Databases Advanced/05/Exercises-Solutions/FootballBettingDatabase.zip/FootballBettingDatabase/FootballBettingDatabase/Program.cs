﻿namespace FootballBettingDatabase
{
    class Program
    {
        static void Main()
        {   
        }
    }
}
