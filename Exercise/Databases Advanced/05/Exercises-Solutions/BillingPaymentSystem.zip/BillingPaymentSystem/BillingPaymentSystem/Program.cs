﻿namespace BillingPaymentSystem
{
    class Program
    {
        static void Main()
        {
            //TphBillsContext context = new TphBillsContext();
            //context.Database.Initialize(true);

            //TptContext tptcontext = new TptContext();
            //tptcontext.Database.Initialize(true);

            //TpcBillsContext tpccontext = new TpcBillsContext();
            //tpccontext.Database.Initialize(true);
        }
    }
}
