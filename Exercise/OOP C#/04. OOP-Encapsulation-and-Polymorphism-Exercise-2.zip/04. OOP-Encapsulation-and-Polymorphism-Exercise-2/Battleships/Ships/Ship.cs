﻿namespace Battleships.Ships
{
    public abstract class Ship
    {
        public bool IsBattleship { get; set; }

        public bool IsDestroyed { get; set; }
    }
}
