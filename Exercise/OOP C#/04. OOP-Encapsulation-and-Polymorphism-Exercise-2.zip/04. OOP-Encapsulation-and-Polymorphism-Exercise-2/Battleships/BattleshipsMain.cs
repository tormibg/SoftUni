﻿namespace Battleships
{
    public class BattleshipsMain
    {
        public static void Main()
        {
            Engine engine = new Engine();

            engine.Run();
        }
    }
}
