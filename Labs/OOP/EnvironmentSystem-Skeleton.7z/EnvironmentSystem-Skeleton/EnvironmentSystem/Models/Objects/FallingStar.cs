﻿using System.Collections;
using System.Collections.Generic;

namespace EnvironmentSystem.Models.Objects
{
    class FallingStar : MovingObject
    {
        public FallingStar(int x, int y, int width, int height, Point direction) : base(x, y, width, height, direction)
        {
            this.ImageProfile = this.GenerateImageProfile();
            this.CollisionGroup = CollisionGroup.Snowflake;
        }

        protected virtual char[,] GenerateImageProfile()
        {
            return new char[,] { { 'O' } };
        }

        public override IEnumerable<EnvironmentObject> ProduceObjects()
        {
            return new EnvironmentObject[]
            {
              new Tail(this.Bounds.TopLeft.X-1,this.Bounds.TopLeft.Y-1,this.Bounds.Width, this.Bounds.Height,this.Direction),
              new Tail(this.Bounds.TopLeft.X-2,this.Bounds.TopLeft.Y-2,this.Bounds.Width, this.Bounds.Height,this.Direction),
              new Tail(this.Bounds.TopLeft.X-3,this.Bounds.TopLeft.Y-3,this.Bounds.Width, this.Bounds.Height,this.Direction),
            };
        }

        public override void RespondToCollision(CollisionInfo collisionInfo)
        {
            var hitObjectGroup = collisionInfo.HitObject.CollisionGroup;
            if (hitObjectGroup == CollisionGroup.Ground)
            {
                this.Exists = false;
            }
        }
    }
}
