﻿using System;
using System.Collections.Generic;
using EnvironmentSystem.Models.DataStructures;

namespace EnvironmentSystem.Models.Objects
{
    public class Star : EnvironmentObject
    {
        private int counter;
        
        public Star(int x, int y, int width, int height) : base(x, y, width, height)
        {
            this.ImageProfile = this.GenerateImageProfile();
            this.CollisionGroup = CollisionGroup.Ground;
            counter = 0;
        }

        protected virtual char[,] GenerateImageProfile()
        {
            char[] chars = new[] {'O', '@', '0'};
            Random rand = new Random();
            var chari = chars[rand.Next(chars.Length)];

            return new char[,] { { chari } };
            
        }

        public Star(Rectangle bounds) : base(bounds)
        {
        }

        public override void Update()
        {
            counter++;
            if (this.counter == 10)
            {
                this.ImageProfile = this.GenerateImageProfile();
                counter = 0;
            }
        }

        public override void RespondToCollision(CollisionInfo collisionInfo)
        {
        }

        public override IEnumerable<EnvironmentObject> ProduceObjects()
        {
            return new EnvironmentObject[0];
        }
    }
}