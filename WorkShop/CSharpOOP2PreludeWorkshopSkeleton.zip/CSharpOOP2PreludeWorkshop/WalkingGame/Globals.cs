﻿namespace WalkingGame
{
    public static class Globals
    {
        public static int GLOBAL_WIDTH = 800;
        public static int GLOBAL_HEIGHT = 600;
    }
}
