'use strict'
function addBefore() {
    $('<li>Insert before</li>').insertBefore('.four');
}
function addAfter() {
    $('.second').after('<li>Insert after</li>');
}
