var Worker = (function () {
    function Worker(name, jobTitle, website) {
        this._name = name;
        this._jobTitle = jobTitle;
        this._website = website;
    }

    return Worker;
})();