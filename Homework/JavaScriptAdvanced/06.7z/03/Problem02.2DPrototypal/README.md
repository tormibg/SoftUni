﻿# Problem02.2DPrototypal


