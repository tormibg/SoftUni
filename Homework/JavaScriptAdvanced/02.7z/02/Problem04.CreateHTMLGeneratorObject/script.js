﻿(function () {
    'use strict';

    var HTMLGen = (function () {

        var createParagraph = function (id, text) {
            var el = document.getElementById(id);
            var newEl = document.createElement('p');
            newEl.innerHTML = text;
            el.appendChild(newEl);
        };

        var createDiv = function(id, classSection) {
            var el = document.getElementById(id);
            var newEl = document.createElement('div');
            newEl.className = classSection;
            el.appendChild(newEl);
        };

        var createLink = function(id, text, url) {
            var el = document.getElementById(id);
            var newEl = document.createElement('a');
            newEl.text = text;
            newEl.href = url;
            el.appendChild(newEl);
        };

        return {
            createParagraph: createParagraph,
            createDiv: createDiv,
            createLink: createLink
        };

    })();

    HTMLGen.createParagraph('wrapper', 'Soft Uni');
    HTMLGen.createDiv('wrapper', 'section');
    HTMLGen.createLink('book', 'C# basics book', 'http://www.introprogramming.info/');
})();
