﻿(function() {
    'use strict';

    function traverse(selector) {
        var el = document.querySelector(selector);
        //console.log(el);

        function traversNode(node,spacing) {
            spacing = spacing || '';
            var nodeId = node.getAttribute('id');
            var nodeClass = node.getAttribute('class');
            var nodeName = node.nodeName.toLowerCase();
            var strToPrint = spacing + nodeName + ':' + (nodeId ? ' id="' + nodeId + '"' : '') + (nodeClass ? ' class="' + nodeClass + '"' : '');
            console.log(strToPrint);
            for (var i = 0; i < node.childNodes.length; i++) {
                var child = node.childNodes[i];
                if (child.nodeType === document.ELEMENT_NODE) {
                    traversNode(child, spacing + '    ');
                }
            }
        }

        traversNode(el,"");
    };

    var selector = ".birds";
    traverse(selector);

})();