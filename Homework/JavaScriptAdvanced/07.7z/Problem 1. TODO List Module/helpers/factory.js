﻿define(['container'], function (Container) {
    return (function () {
        var toDoList = new Container('Tuesday TODO List');
        return toDoList;
    })();
});