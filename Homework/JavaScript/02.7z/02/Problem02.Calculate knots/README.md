﻿# Problem02.Calculate knots


