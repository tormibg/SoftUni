﻿# Problem05.ArrayPrototypeFunction


