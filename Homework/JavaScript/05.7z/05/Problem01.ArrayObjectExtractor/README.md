﻿# Problem01.ArrayObjectExtractor


