﻿function replaceATag(str) {
    var result =  str.replace(/<a/g, "[URL").replace(/>SoftUni<\/a>/g,"]SoftUni[/URL]");
    console.log(result);
};

replaceATag("<ul><li><a href=http://softuni.bg>SoftUni</a></li></ul>");