﻿namespace Animals.Interface
{
    interface ISoundProducible
    {
        void ProduceSound();
    }
}
