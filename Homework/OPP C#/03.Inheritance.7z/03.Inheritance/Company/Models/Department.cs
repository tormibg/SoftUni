﻿namespace Company.Models
{
    public enum Department
    {
        Production, Accounting, Sales, Marketing
    }
}
