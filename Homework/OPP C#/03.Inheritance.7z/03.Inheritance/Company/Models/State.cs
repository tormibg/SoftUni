﻿namespace Company.Models
{
    public enum State
    {
        Open, Closed
    }
}
