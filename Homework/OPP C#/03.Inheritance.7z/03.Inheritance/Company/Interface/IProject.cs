﻿namespace Company.Interfaces
{
    using System;
    using System.Collections.Generic;
    using Models;

    public interface IProject
    {
        string ProjectName { get; set; }

        string Details { get; set; }

        DateTime StDate { get; set; }

        void CloseProject();
    }
}