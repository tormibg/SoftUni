﻿namespace HSW
{
    public abstract class Human
    {
        protected Human(string firstname, string lastName)
        {
        }
    }
}
