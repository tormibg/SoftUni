﻿namespace TheSlum
{
    public enum Team
    {
        Red,
        Blue
    }
}