﻿namespace Customer
{
    public enum CustomerType
    {
        //One-time , Regular, Golden, Diamond
        Onetime,
        Regular,
        Golden,
        Diamond
    }
}