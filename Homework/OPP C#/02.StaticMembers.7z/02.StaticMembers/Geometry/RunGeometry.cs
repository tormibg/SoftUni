﻿
namespace Geometry
{
    class RunGeometry
    {
        static void Main()
        {
        }
    }
}
