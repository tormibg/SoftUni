﻿namespace BankofKK.Models
{
    public enum TypeCustomer
    {
        Individual,
        Company
    }
}