﻿using System;

namespace TheSlum
{
    using GameEngine;

    public class TheSlum
    {
        public static void Main()
        {
            NewEngine engine = new NewEngine();
            engine.Run();
        }
    }
}
