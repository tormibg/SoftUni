﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tmp
{
    class Program
    {
        static void Main(string[] args)
        {
            Animal asa = new Animal();
            Dog asad = new Dog();
            asad.Greet();
        }
    }
    public class Animal
    {
        public void Greet()
        {
            Console.WriteLine("Hello, I'm some sort of animal!");
        }
    }

    public class Dog : Animal
    {

    }
}
