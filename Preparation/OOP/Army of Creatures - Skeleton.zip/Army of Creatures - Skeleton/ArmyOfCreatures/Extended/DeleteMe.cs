﻿namespace ArmyOfCreatures.Extended
{
    public class DeleteMe
    {
        // You can safely delete this file
    }
}
