﻿namespace SoftUniStore.App
{
    public class Contracts
    {
        
    }
}