﻿namespace SoftUniStore.App.BindingModels
{
    public class BuyGameBindingModel
    {
        public int Gameid { get; set; }
       // public int UserId { get; set; }
    }
}