﻿namespace SoftUniStore.App.BindingModels
{
    public class LoginUserBindingModel
    {
        public string Email { get; set; }

        public string Password { get; set; }
    }
}