﻿namespace MassDefect.DTOs
{
    public class AnomalyVictimDTO
    {
        public int Id { get; set; }

        public string Person { get; set; }
    }
}