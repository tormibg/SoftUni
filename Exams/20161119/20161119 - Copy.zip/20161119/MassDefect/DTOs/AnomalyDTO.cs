﻿using MassDefect.Models;

namespace MassDefect.DTOs
{
    public class AnomalyDTO
    {
        public string OriginPlanet { get; set; }

        public string TeleportPlanet { get; set; }
    }
}