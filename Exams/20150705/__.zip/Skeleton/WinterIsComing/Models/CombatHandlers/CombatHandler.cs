﻿using System;
using System.Collections.Generic;
using System.Linq;
using WinterIsComing.Contracts;
using WinterIsComing.Core;
using WinterIsComing.Core.Exceptions;
using WinterIsComing.Models.Spells;
using WinterIsComing.Models.Units;

namespace WinterIsComing.Models.CombatHandlers
{
    public class CombatHandler : ICombatHandler
    {
        private const int IceGiantIncreasePointsAfterCastSpell = 5;
        private Units.Unit unit;
        private int mageCastSpells ;

        public CombatHandler(Units.Unit unit)
        {
            this.Unit = unit;
        }


        public IUnit Unit { get; set; }


        public IEnumerable<IUnit> PickNextTargets(IEnumerable<IUnit> candidateTargets)
        {
            switch (this.Unit.GetType().Name)
            {
                case "IceGiant":
                    return IceGiantComabatHandler(candidateTargets);
                case "Mage":
                    return MageComabatHandler(candidateTargets);
                case "Warrior":
                    return WarriorComabatHandler(candidateTargets);
                default:
                    throw new GameException(String.Format("Unknown type of unit"));
            }
        }

        private IEnumerable<IUnit> IceGiantComabatHandler(IEnumerable<IUnit> candidateTargets)
        {
            IList<IUnit> units = new List<IUnit>();
            foreach (IUnit nextTarget in candidateTargets)
            {
                units.Add(nextTarget);
                if (this.Unit.HealthPoints <= 150)
                {
                    return units;
                }
            }
            return units;
        }

        private IEnumerable<IUnit> MageComabatHandler(IEnumerable<IUnit> candidateTargets)
        {
            int count = 1;
            IList<IUnit> units = new List<IUnit>();
            var nextTargets = candidateTargets.OrderByDescending( x => x.HealthPoints).ThenBy(x => x.Name).ToList();
            foreach (IUnit nextTarget in nextTargets)
            {
                units.Add(nextTarget);
                count++;
                if (count == 3)
                {
                    return units;
                }               
            }
            return units;
        }

        private IEnumerable<IUnit> WarriorComabatHandler(IEnumerable<IUnit> candidateTargets)
        {
            IList<IUnit> units = new List<IUnit>();
            var nextTargets = candidateTargets.OrderByDescending(x => x.HealthPoints).ThenBy(n => n.Name).ToList();
            foreach (IUnit nextTarget in nextTargets)
            {
                units.Add(nextTarget);
                return units;
            }
            return units;
        }

        public ISpell GenerateAttack()
        {
            switch (this.Unit.GetType().Name)
            {
                case "IceGiant":
                    var IceGiantSpell = IceGiantSpellHandler();

                    if (Unit.EnergyPoints - IceGiantSpell.EnergyCost <= 0)
                    {
                        throw new GameException(String.Format(GlobalMessages.NotEnoughEnergy,this.Unit.Name,IceGiantSpell.GetType().Name));
                    }

                    this.Unit.EnergyPoints -= IceGiantSpell.EnergyCost;
                    this.Unit.AttackPoints += IceGiantIncreasePointsAfterCastSpell;
                    return IceGiantSpell;
                case "Mage":
                    ISpell mageSpell = null;
                    if (mageCastSpells == 0)
                    {
                        mageSpell = MageSpellHandlerFireBreath();
                    }
                    else
                    {
                        mageSpell = MageSpellHandlerBlizzard();
                    }

                    if (Unit.EnergyPoints - mageSpell.EnergyCost <= 0)
                    {
                        throw new GameException(String.Format(GlobalMessages.NotEnoughEnergy, this.Unit.Name, mageSpell.GetType().Name));
                    }
                    mageCastSpells++;
                    if (mageCastSpells > 1)
                    {
                        mageCastSpells = 0;
                    }
                    this.Unit.EnergyPoints -= mageSpell.EnergyCost;
                    return mageSpell;
                case "Warrior":
                    var warSpell = WarriorSpellHandler();
                    if (this.Unit.HealthPoints > 50)
                    {
                        this.Unit.EnergyPoints -= warSpell.EnergyCost;    
                    }
                    return warSpell;
                default:
                    throw new GameException(String.Format("Unknown type of unit"));
            }
        }

        private ISpell IceGiantSpellHandler()
        {
            var spell = new Stomp(this.Unit.AttackPoints);
            return spell;
        }


        private ISpell MageSpellHandlerFireBreath()
        {
                return new FireBreath(this.Unit);
        }

        private ISpell MageSpellHandlerBlizzard()
        {
                return new Blizzard (this.Unit);
        }

        private ISpell WarriorSpellHandler()
        {
            var spell = new Cleave(this.Unit);
            return spell;
        }
    }
}