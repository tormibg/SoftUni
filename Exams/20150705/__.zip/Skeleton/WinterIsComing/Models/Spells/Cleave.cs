﻿using WinterIsComing.Contracts;

namespace WinterIsComing.Models.Spells
{
    public class Cleave : ISpell
    {
        private const int CleaveEnergyCost = 15;

        private readonly IUnit unit; 

        public Cleave(IUnit unit)
        {
            this.unit = unit;
            this.Damage = unit.AttackPoints;
            this.EnergyCost = CleaveEnergyCost;
        }

        public int Damage {
            get {
                if (this.unit.HealthPoints <= 80)
                {
                    return unit.AttackPoints + unit.HealthPoints*2;
                }
                return this.unit.AttackPoints;
            }
            private set { value = this.unit.AttackPoints; }
        }
        public int EnergyCost { get; private set; }

    }
}