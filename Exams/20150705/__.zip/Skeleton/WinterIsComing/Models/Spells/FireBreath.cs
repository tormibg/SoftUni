﻿using WinterIsComing.Contracts;

namespace WinterIsComing.Models.Spells
{
    public class FireBreath : ISpell
    {
        private const int FireBreathEnergyCost = 30;

        private readonly IUnit unit;

        public FireBreath(IUnit unit)
        {
            this.unit = unit;
            this.Damage = unit.AttackPoints;
            this.EnergyCost = FireBreathEnergyCost;
        }

        public int Damage
        {
            get
            {return this.unit.AttackPoints;
            }
            private set { value = this.unit.AttackPoints; }
        }
        public int EnergyCost { get; private set; }

    }
}