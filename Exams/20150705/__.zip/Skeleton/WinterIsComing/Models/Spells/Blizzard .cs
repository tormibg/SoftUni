﻿using WinterIsComing.Contracts;

namespace WinterIsComing.Models.Spells
{
    public class Blizzard  : ISpell
    {
        private const int BlizzardEnergyCost = 40;

        private readonly IUnit unit;

        public Blizzard(IUnit unit)
        {
            this.unit = unit;
            this.Damage = unit.AttackPoints;
            this.EnergyCost = BlizzardEnergyCost;
        }

        public int Damage
        {
            get
            {
                return this.unit.AttackPoints * 2;
            }
            private set { value = this.unit.AttackPoints; }
        }
        public int EnergyCost { get; private set; }

    }
}