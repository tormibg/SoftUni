﻿using WinterIsComing.Contracts;

namespace WinterIsComing.Models.Spells
{
    public class Stomp : ISpell
    {
        private const int StompEnergyCost = 15;

        private int damage;

        public Stomp(int damage)
        {
            this.Damage = damage;
            this.EnergyCost = StompEnergyCost;
        }

        public int Damage
        {
            get
            {
                return this.damage;
            }
            private set { this.damage = value; }
        }
        public int EnergyCost { get; private set; }

    }
}